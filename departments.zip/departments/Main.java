package com.greatlearning.departments;

public class Main {



	public static void main(String args[]) {

		hrDepartment hr = new hrDepartment();
		techDepartment tech = new techDepartment();
		adminDepartment admin  = new adminDepartment();


		/* Admin Department */

		String name = admin.departmentName();
		System.out.println(name);

		String today = admin.getTodaysWork();
		System.out.println(today);

		String line = admin.getWorkDeadline();
		System.out.println(line);


		System.out.println(admin.isTodayAHoliday());

		System.out.println();

		/* HR Department*/

		String deptName = hr.departmentName();
		System.out.println(deptName);

		String activity = hr.doActivity();
		System.out.println(activity);

		String work = hr.getTodaysWork();
		System.out.println(work);

		String deadLine = hr.getWorkDeadline();
		System.out.println(deadLine);

		System.out.println(hr.isTodayAHoliday());

		System.out.println();

		/* Tech Department*/

		String dept = tech.departmentName();
		System.out.println(dept);

		String todaysWork = tech.getTodaysWork();
		System.out.println(todaysWork);

		String workDeadLine = tech.getWorkDeadline();
		System.out.println(workDeadLine);

		String stack = tech.getTechStackInformation();
		System.out.println(stack);

		System.out.println(tech.isTodayAHoliday());


	}
}
