package com.greatlearning.departments;

public class superDepartment {

	String departmentName() {
		return "Super Department";

	}

	String getTodaysWork() {
		return "No work as of now";
	}

	String getWorkDeadline() {
		return "Nil";
	}

	String isTodayAHoliday(){
		return "Today is not a holiday";
	}
}
