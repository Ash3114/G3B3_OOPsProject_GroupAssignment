package com.greatlearning.departments;

public interface Departments {

	String superDepartment();
	String adminDepartment();
	String hrDepartment();
	String techDepartment();


}
