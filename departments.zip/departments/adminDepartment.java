package com.greatlearning.departments;

public class adminDepartment extends superDepartment{

	String departmentName() {
		return "Admin Department";
	}

	String getTodaysWork() {
		return "Complete your documents Submission";
	}

	String getWorkDeadline() {
		return "Complete by EOD";
	}

}
