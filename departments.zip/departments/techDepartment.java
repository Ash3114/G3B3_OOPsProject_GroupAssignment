package com.greatlearning.departments;

public class techDepartment extends superDepartment{

	String departmentName() {
		return "Tech Department";
	}

	String getTodaysWork() {
		return "Complete coding of module 1";
	}

	String getWorkDeadline() {
		return "Complete by EOD";
	}

	String getTechStackInformation() {
		return "Core Java";
	}

}
